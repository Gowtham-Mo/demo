package com.example.demo.controller;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;

@DataJpaTest
public class ProductControllerTest {
	@Autowired
	private TestEntityManager entityManager;
	
	@Autowired
	private ProductRepository repo;
	
	@Test
	//@Rollback(false)
	public void testSaveNewProduct() {
		entityManager.persist(new Product(1,1212, 59999, "iPhone 12"));
				
		Product product = repo.findByproductName("iPhone 12");
		
		assertThat(product.getProductName()).isEqualTo("iPhone 12");
	}
	
	@Test
	//@Rollback(false)
	public void testCreateProduct() {
		//Product savedProduct = repo.save(new Product(198, 43999, "iPhone 10"));
		Product savedProduct = entityManager.persist(new Product(1,1212, 59999, "iPhone 12"));
		assertThat(savedProduct.getProductId()).isGreaterThan(0);
	}
	@Test
	public void testListProducts() {
		entityManager.persist(new Product(1,1212, 59999, "iPhone 12"));
		List<Product> products = (List<Product>) repo.findAll();
		assertThat(products).size().isGreaterThan(0);
	}
	@Test
	@Rollback(false)
	public void testDeleteProduct() {
		entityManager.persist(new Product(1,1212, 59999, "iPhone 12"));
		Product product = repo.findByproductName("iPhone 12");
		
		repo.deleteById(product.getProductId());
		
		Product deletedProduct = repo.findByproductName("iPhone 12");
		
		assertThat(deletedProduct).isNull();		
		
	}
}