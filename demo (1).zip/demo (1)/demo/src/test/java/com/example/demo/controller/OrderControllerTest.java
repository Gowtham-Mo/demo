package com.example.demo.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

import com.example.demo.model.Ordered;
import com.example.demo.repository.OrderRepository;

@DataJpaTest
public class OrderControllerTest {
	@Autowired
	private TestEntityManager entity;
	
	@Autowired
	private OrderRepository repo;
	
	@Test
	//@Rollback(false)
	public void testSaveNewOrder() {
		entity.persist(new Ordered(1,1,3,"12-March-21","14-March-21","16-March-21","delivered","online","Success"));
				
		Ordered order = repo.findByProductIdAndCustomerId(3,1);
		
		assertThat(order.getProductId()).isEqualTo(3);
		assertThat(order.getCustomerId()).isEqualTo(1);
	}
	
	@Test
	//@Rollback(false)
	public void testCreateOrder() {
		//Product savedProduct = repo.save(new Product(198, 43999, "iPhone 10"));
		Ordered savedorder = entity.persist(new Ordered(1,1,3,"12-March-21","14-March-21","16-March-21","delivered","online","Success"));
		assertThat(savedorder.getOrderId()).isGreaterThan(0);
	}
	@Test
	public void testListOrder() {
		entity.persist(new Ordered(1,1,3,"12-March-21","14-March-21","16-March-21","delivered","online","Success"));
		List<Ordered> orders = (List<Ordered>) repo.findAll();
		assertThat(orders).size().isGreaterThan(0);
	}
	@Test
	@Rollback(false)
	public void testDeleteOrder() {
		entity.persist(new Ordered(1,1,3,"12-March-21","14-March-21","16-March-21","delivered","online","Success"));
		Ordered order = repo.findByProductIdAndCustomerId(3,1);
		
		repo.deleteById(order.getOrderId());
		
		Ordered deletedorder = repo.findByProductIdAndCustomerId(3,1);
		
		assertThat(deletedorder).isNull();		
		
	}
}