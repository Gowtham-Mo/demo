package com.example.demo.model;

import java.util.Date;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Ordered {
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private int orderId;
	private int customerId;
	private int productId;
	private String orderPlacedDate;
	private String orderDispatchedDate;
	private String orderDeliveredDate;
	private String orderStatus;
	private String paymentSource;
	private String paymentStatus;

	
	
	public Ordered(int orderId, int customerId, int productId, String orderPlacedDate, String orderDispatchedDate,
			String orderDeliveredDate, String orderStatus, String paymentSource, String paymentStatus) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.productId = productId;
		this.orderPlacedDate = orderPlacedDate;
		this.orderDispatchedDate = orderDispatchedDate;
		this.orderDeliveredDate = orderDeliveredDate;
		this.orderStatus = orderStatus;
		this.paymentSource = paymentSource;
		this.paymentStatus = paymentStatus;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", customerId=" + customerId + ", productId=" + productId
				+ ", orderPlacedDate=" + orderPlacedDate + ", orderDispatchedDate=" + orderDispatchedDate
				+ ", orderDeliveredDate=" + orderDeliveredDate + ", orderStatus=" + orderStatus + ", paymentSource="
				+ paymentSource + ", paymentStatus=" + paymentStatus + "]";
	}

	public Ordered() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getOrderPlacedDate() {
		return orderPlacedDate;
	}

	public void setOrderPlacedDate(String orderPlacedDate) {
		this.orderPlacedDate = orderPlacedDate;
	}

	public String getOrderDispatchedDate() {
		return orderDispatchedDate;
	}

	public void setOrderDispatchedDate(String orderDispatchedDate) {
		this.orderDispatchedDate = orderDispatchedDate;
	}

	public String getOrderDeliveredDate() {
		return orderDeliveredDate;
	}

	public void setOrderDeliveredDate(String orderDeliveredDate) {
		this.orderDeliveredDate = orderDeliveredDate;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getPaymentSource() {
		return paymentSource;
	}

	public void setPaymentSource(String paymentSource) {
		this.paymentSource = paymentSource;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	
}
