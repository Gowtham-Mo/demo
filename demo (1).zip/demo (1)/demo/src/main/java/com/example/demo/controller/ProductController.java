package com.example.demo.controller;
import java.sql.Array;
import java.util.ArrayList;

import org.apache.coyote.Response;
//import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.ProductDao;
import com.example.demo.model.Product;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	
	@Autowired
	ProductDao productDao;
	
	/*@RequestMapping(value="/index")
	public String Hello()
	{
		return "index";
	}*/
	
	
    @RequestMapping(value="/add")
    public Product addProduct(@RequestBody Product p) {
       
    	productDao.addProduct(p);
    	return p;
    }
    
    
    @RequestMapping(value="/v1/get/info")
    public ArrayList<Product> getAllProduct()
    {
    	ArrayList<Product> p=productDao.getAllProduct();
          return p;
    }
    
}