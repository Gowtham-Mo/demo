package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {

	@Id
	private int productId;
	private int brandId;
	private int price;
	private String productName;
	
	

	public Product(int productId, int brandId, int price, String productName) {
		super();
		this.productId = productId;
		this.brandId = brandId;
		this.price = price;
		this.productName = productName;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getBrandId() {
		return brandId;
	}

	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "product [productName=" + productName + ", productId=" + productId + ", brandId=" + brandId + ", price="
				+ price + "]";
	}

}
