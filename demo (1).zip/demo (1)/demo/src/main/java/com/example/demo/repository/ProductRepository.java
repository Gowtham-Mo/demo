package com.example.demo.repository;

//import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Product;


public interface ProductRepository extends CrudRepository<Product, Integer>  {
	
	public Product findByproductName(String productName);

}
