package com.example.demo.dao;

import java.lang.*;
import java.util.ArrayList;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;
import com.example.demo.services.ProductServices;

@Repository
public class ProductDao implements ProductServices {
	@Autowired
	private ProductRepository productRepository;

	@Override
	public Product addProduct(Product product) {
        productRepository.save(product);
		// TODO Auto-generated method stub
		return product;
	}

	@Override
	public ArrayList<Product> getAllProduct() {
		 ArrayList<Product> p =(ArrayList<Product>)productRepository.findAll();
		
		
		
		// TODO Auto-generated method stub
		return p;
	}

	@Override
	public Product getProductById(int ProductId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteProduct(int ProductId) {
		// TODO Auto-generated method stub

	}

}
