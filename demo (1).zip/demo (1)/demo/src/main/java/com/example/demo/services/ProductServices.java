package com.example.demo.services;

import java.util.List;                                                                                               

import org.springframework.stereotype.Service;

import com.example.demo.model.Ordered;
import com.example.demo.model.Product;

@Service
public interface ProductServices {
	
	public Product addProduct(Product product);
	
	
	public List<Product> getAllProduct();
	public Product getProductById(int ProductId);
	public Product updateProduct(Product product);
	public void deleteProduct(int ProductId);
	
}
