package com.example.demo.controller;

import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.OrderDao;
import com.example.demo.model.Ordered;

@RestController
public class OrderController {
	
	@Autowired
	public OrderDao dao;
	
	@RequestMapping("/placeOrder")
	public Ordered placeOrder(@RequestBody Ordered o)
	{
		Ordered order=dao.placeOrder(o);
		return order;
	}
	
	@RequestMapping(value = "/order/v1/submit")
	public int getOrderId(@RequestBody Map<String, String> json) {

		int n = dao.getOrderId(json.get("orderPlacedDate"), Integer.parseInt(json.get("productId")),
				Integer.parseInt(json.get("customerId")));
		return n;
	}
}
