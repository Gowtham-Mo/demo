package com.example.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Ordered;



public interface OrderRepository extends CrudRepository<Ordered, Integer> {

	public Ordered findByProductIdAndCustomerId(int productId,int customerId);
	public Ordered findByProductId(int productId);
	
}
