package com.example.demo.model;

public class Brand {
	
	private String brandName;
	private int brandId;
	private int quantity;
	private String brandAvailableStatus;
	public Brand() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Brand [brandName=" + brandName + ", brandId=" + brandId + ", quantity=" + quantity
				+ ", brandAvailableStatus=" + brandAvailableStatus + "]";
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public int getBrandId() {
		return brandId;
	}
	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getBrandAvailableStatus() {
		return brandAvailableStatus;
	}
	public void setBrandAvailableStatus(String brandAvailableStatus) {
		this.brandAvailableStatus = brandAvailableStatus;
	}

}
