package com.example.demo.services;

import org.springframework.stereotype.Service;

import com.example.demo.model.Ordered;
import com.example.demo.model.Product;

@Service
public interface OrderServices {
	
	
	public Ordered placeOrder(Ordered order);
	public int  getOrderId(String orderPlacedDate,int productId,int customerId );
}
