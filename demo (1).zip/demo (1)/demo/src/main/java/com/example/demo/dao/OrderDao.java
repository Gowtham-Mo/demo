package com.example.demo.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Ordered;
import com.example.demo.repository.OrderRepository;
import com.example.demo.services.OrderServices;

@Repository
public class OrderDao implements OrderServices {

	@Autowired
	private OrderRepository orderRepository;
	
	
	
	@Override
	public Ordered placeOrder(Ordered order) {
		
		Ordered o=orderRepository.save(order);
		return o;
	}



	@Override
	public int getOrderId(String orderPlacedDate, int productId, int customerId) {
		Ordered o=(Ordered)orderRepository.findByProductIdAndCustomerId(productId,customerId);
		return o.getOrderId();
	}
	

}
